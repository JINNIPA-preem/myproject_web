from ttkbootstrap import Style
from ttkbootstrap.widgets import Meter
from ttkbootstrap.widgets import Floodgauge
import tkinter as tk
from tkinter import ttk,StringVar
from PIL import Image,ImageTk
import threading
from continuous_threading import PeriodicThread

import serial
import time

ser = serial.Serial("COM2",9600)
if not(ser.is_open):
        ser.open()    
time.sleep(1)

def send_a():
    ser.write(str.encode("a"))

def send_b():
    ser.write(str.encode("b"))

def send_c():
    ser.write(str.encode("c"))

def send_d():
    ser.write(str.encode("d"))

def ser_read():
    try:
        if ser.inWaiting():
                textin = ser.readline().decode()[:-2]
                if textin.startswith("tp"):
                        temp = textin.strip("tp")
                        lb8.config(text=temp)

                elif textin.startswith("li"):
                        light = textin.strip("li")
                        lb11.config(text=light)
                        
                elif textin.startswith("sm"):
                        soil = textin.strip("sm")
                        meter.amountused = int(soil)

                elif textin.startswith("wt"):
                        water = textin.strip("wt")
                        lb14.config(text="ระดับน้ำ"+water+"%")
                        fg1.value = int(water)
    except:
        pass

#********************************************
style = Style(theme="minty")
window = style.master
window.title("GreenHouse")
window.geometry("765x400")

#********************************************
lb0 = ttk.Label(window,text="- GreenHouse -",font=("Helvetica 30 bold"),anchor=tk.CENTER,foreground="#56cc9d")
lb0.place(x=0,y=20,width=765)

#********************************************
lb1 = ttk.Label(window,text="หลอดไฟ",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb1.place(x=0,y=100,width=150)
style.configure("Outline.TButton",font=("Helvetica 10 bold"))
bt2 = ttk.Button(window,text="เปิดไฟ",cursor="hand2",style="warning.Outline.TButton",command=send_a)
bt2.place(x=130,y=100,width=75)
bt3 = ttk.Button(window,text="ปิดไฟ",cursor="hand2",style="danger.Outline.TButton",command=send_b)
bt3.place(x=210,y=100,width=75)

#********************************************
lb4 = ttk.Label(window,text="ประตู",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb4.place(x=0,y=150,width=150)
style.configure("Outline.TButton",font=("Helvetica 10 bold"))
bt5 = ttk.Button(window,text="เปิดประตู",cursor="hand2",style="success.Outline.TButton",command=send_c)
bt5.place(x=130,y=150,width=75)
bt6 = ttk.Button(window,text="ปิดประตู",cursor="hand2",style="danger.Outline.TButton",command=send_d)
bt6.place(x=210,y=150,width=75)

#********************************************
lb7 = ttk.Label(window,text="อุณหภูมิ",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb7.place(x=0,y=200,width=150)
lb8 = ttk.Label(window,text="0",font=("Helvetica 40 bold"),anchor=tk.CENTER,foreground="#f3969a")
lb8.place(x=0,y=250,width=150)
lb9 = ttk.Label(window,text="องศาเซลเซียส",font=("Helvetica 15 bold"),anchor=tk.CENTER)
lb9.place(x=0,y=320,width=150)

#********************************************
lb10 = ttk.Label(window,text="เเสงสว่าง",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb10.place(x=150,y=200,width=150)
lb11 = ttk.Label(window,text="0",font=("Helvetica 40 bold"),anchor=tk.CENTER,foreground="#ffce67")
lb11.place(x=150,y=250,width=150)
lb12 = ttk.Label(window,text="%",font=("Helvetica 15 bold"),anchor=tk.CENTER)
lb12.place(x=150,y=320,width=150)

#********************************************
lb13 = ttk.Label(window,text="ความชื้นในดิน",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb13.place(x=325,y=100,width=200)
meter = Meter(window,metersize=200,stripethickness=20,amounttotal=100,labeltext='ความชื้น',textappend='%',meterstyle='success.TMeter',interactive=True)
meter.place(x=325,y=150)

#********************************************
lb14 = ttk.Label(window,text="ระดับน้ำ 50%",font=("Helvetica 20 bold"),anchor=tk.CENTER)
lb14.place(x=550,y=100,width=200)
fg1 = Floodgauge(window,value=50,style='info.Vertical.TFloodgauge',orient='vertical')
fg1.place(x=570,y=150,width=150,height=200)

#********************************************
PeriodicThread(0.25,ser_read).start()
window.mainloop()

